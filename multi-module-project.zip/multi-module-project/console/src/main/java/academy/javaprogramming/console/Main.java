package academy.javaprogramming.console;

import academy.javaprogramming.Game;
import academy.javaprogramming.MessageGenerator;
import academy.javaprogramming.NumberGenerator;
import academy.javaprogramming.config.AppConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@Slf4j
public class Main {
    // private static final Logger logger = LoggerFactory.getLogger(Main.class);
    /*private static final String CONFIG_LOCATION = "beans.xml";*/

    public static void main(String[] args) {
        log.info("Core logger info");

        /*ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext(CONFIG_LOCATION);*/
        ConfigurableApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        NumberGenerator numberGenerator = applicationContext.getBean(NumberGenerator.class);

        int number = numberGenerator.next();
        log.info("Number = {}", number);

        Game game = applicationContext.getBean(Game.class);
        // game.reset();

        MessageGenerator msgGen = applicationContext.getBean(MessageGenerator.class);
        log.info("academy.javaprogramming.console.Main message - {}", msgGen.getMainMessage());
        log.info("Result Messsage - {}", msgGen.getResultMessage());

        applicationContext.close();
    }
}
