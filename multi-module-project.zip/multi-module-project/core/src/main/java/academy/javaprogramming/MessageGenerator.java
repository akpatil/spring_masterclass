package academy.javaprogramming;

public interface MessageGenerator {
    String getMainMessage();
    String getResultMessage();
}
